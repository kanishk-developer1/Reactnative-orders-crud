export const STATUS_CONST ={
    RECEIVED: 'Received',
    ACCEPTED: 'Accepted',
    PACKED: 'Packed',
    DELIVERED: 'Delivered',
    VERIFIED: 'Verified'
}

export const NEXT_STATUS_BTN_CONST ={
    Received: 'Accept',
    Accepted: 'Pack',
    Packed: 'Deliver',
    Delivered: 'Verify'
}

export const NEXT_STATUS_CONST ={
    Received: 'Accepted',
    Accepted: 'Packed',
    Packed: 'Delivered',
    Delivered: 'Verified'
}